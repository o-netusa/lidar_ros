/**************************************************************************
 * @file:  PointCloudProcessor.h
 * @brief:
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <DeviceParams.h>
#include <DolphinDevice.h>
#include <PointCloud.h>
#include <common/Global.h>

#include <memory>

namespace onet { namespace lidar { namespace processing {

template <typename POINT_T>
struct PointClouds
{
    PointClouds() = default;
    PointClouds(uint32_t point_size)
    {
        pointcloud_zero.reserve(point_size);
        pointcloud_one.reserve(point_size);
        filtered_pointcloud_zero.reserve(point_size);
        filtered_pointcloud_one.reserve(point_size);
    }

    PointCloud<POINT_T> pointcloud_zero;
    PointCloud<POINT_T> pointcloud_one;
    PointCloud<POINT_T> filtered_pointcloud_zero;
    PointCloud<POINT_T> filtered_pointcloud_one;
};

struct PreMirrorIdx
{
    PreMirrorIdx()
    {
        pre_mirror_idx_zero = 6;
        pre_mirror_idx_one = 6;
    }

    uint32_t pre_mirror_idx_zero;
    uint32_t pre_mirror_idx_one;
};

struct Directions
{
    Directions()
    {
        direction_zero = -1;
        direction_one = -1;
        is_changed_direction_zero = false;
        is_changed_direction_one = false;
    }

    int32_t direction_zero;
    int32_t direction_one;
    bool is_changed_direction_zero;
    bool is_changed_direction_one;
};

struct NoiseCheckParam
{
    NoiseCheckParam()
    {
        bx = 0.0;
        by = 0.0;
        bz = 0.0;
        cur_in_line = false;
    }

    float bx;  // point before the previous point
    float by;
    float bz;
    bool cur_in_line;  // current point in a line
};

enum class NoisePointDispMode
{
    ONLY_DISPLAY_NOISE_POINT = 1,
    ONLY_DISPLAY_NORMAL_POINT,
    DISPLAY_ALL_POINTS
};

/**
 * @brief Enable or disable noise points removal
 * true: enable, false: disable
 */
void DLLEXPORT SetRemovedNoisePoints(const bool& value);

/**
 * @brief Noise point disply mode
 * 1:noise 2:non-noise 3:all
 */
void DLLEXPORT SetNoisePointDispMode(const enum NoisePointDispMode& mode);

/**
 * @brief Set noise distance threshold in meter, larger number means less noise points
 */
void DLLEXPORT SetNoiseDistThreshold(const float& value);

/**
 * @brief Set noise squared area (0 ~ 1) for filtering out the wrong noise points, larger number
 * means more wrong noise points which are corrected, however, larger number means more correct
 * noise points which are not considered as noise points
 */
void DLLEXPORT SetNoiseAreaSq(const float& value);

/**
 * @brief Set noise range in meter, only filter out noise point inside this range
 */
void DLLEXPORT SetNoiseRange(const float& value);

template <typename POINT_T>
void UpdatePointcloudAftProcessing(PointCloud<POINT_T>& pointcloud_channel,
                                   PointCloud<POINT_T>& filtered_pointcloud, bool cur_in_line,
                                   bool& is_changed_direction, uint32_t& pre_mirror_idx,
                                   PointCloud<POINT_T>& pointcloud);

bool DLLEXPORT InitDeviceParams(DlphDeviceParameter* dev_params);

template <typename POINT_T>
void ProcessFPGARawDataEigen(const DlphDeviceParameter& dev_param, const DlphFPGAData& data,
                             uint32_t& point_idx, PointCloud<POINT_T>& pointcloud);

template <typename POINT_T>
void ProcessFPGARawData(const DlphDeviceParameter& dev_param, const DlphFPGAData& data,
                        PointCloud<POINT_T>& cloud, PointCloud<POINT_T>& filtered_cloud,
                        uint32_t& pre_mirror_idx, NoiseCheckParam& noise_check_param);

template <typename POINT_T>
void NoiseRemoval(uint32_t& mirror_idx, uint32_t& pre_mirror_idx,
                  NoiseCheckParam& noise_check_param, POINT_T point,
                  PointCloud<POINT_T>& filtered_cloud, PointCloud<POINT_T>& cloud);

template <typename POINT_T>
void DLLEXPORT ProcessFPGARawDataNoiseRemoval(const DlphDeviceParameter& dev_param,
                                              const DlphFPGAData& fpga,
                                              PointClouds<POINT_T>& pointcloud_channels,
                                              PreMirrorIdx& pre_mirror_idx, Directions& directions,
                                              NoiseCheckParam& noise_check_param_zero,
                                              NoiseCheckParam& noise_check_param_one,
                                              PointCloud<POINT_T>& pointcloud);

bool GetLeftSource(float data, int32_t& left_source, bool is_max, DlphDeviceParameter* dev_params);

bool GetGalvanometerParameter(const std::vector<uint16_t>& in_data, std::vector<uint16_t>& put_data,
                              DlphDeviceParameter* dev_params);

template <typename POINT_T>
void SetPoint(POINT_T& point, float i, int sec_num, int pulse_wid, int echo_number, int mirror,
              int azm, int elv, int dist);

bool DLLEXPORT CalculateTheoreticalPointsInBox(const DlphDeviceParameter& dev_param,
                                               const float angle_box_up, const float angle_box_down,
                                               const float angle_box_left,
                                               const float angle_box_right,
                                               uint32_t& num_points_in_box);

/**
 * @brief Calculate the theoretical points in the specified bounding box based on the collected raw
 * data
 */
bool DLLEXPORT CalculateTheoreticalPointsInBoxUsingData(
    const DlphDeviceParameter& dev_param, const DlphFPGAData& data, const float angle_box_up,
    const float angle_box_down, const float angle_box_left, const float angle_box_right,
    uint32_t& num_points_in_box);

}}}  // namespace onet::lidar::processing
