/**************************************************************************
 * @file:  DolphinDevice.h
 * @brief:
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <type_traits>
#include <vector>

#include "DeviceParams.h"

namespace onet { namespace lidar {

// command
constexpr uint32_t DLPH_REG_WRITE_FLAG = 0xB2B2A3A3;
constexpr uint32_t DLPH_CMD_HEADER_1 = 0xA5A50011;
constexpr uint32_t DLPH_CMD_HEADER_2 = 0xAABBCCDD;
constexpr uint32_t DLPH_CMD_END = 0xA5A6A7A8;

// galvanometer
constexpr uint32_t DLPH_GALVANO_CMD_HEADER_REQ = 0xE5E5E5E5;
constexpr uint32_t DLPH_GALVANO_CMD_END_REQ = 0xA7A7A7A7;
constexpr uint32_t DLPH_GALVANO_CMD_HEADER_RES = 0xE7E7E7E7;
constexpr uint32_t DLPH_GALVANO_CMD_END_RES = 0xA6A6A6A6;

constexpr uint32_t DLPH_GALVANO_PKG_SIZE = 0x404;  // 1028

// send <Read Register command>
constexpr uint32_t DLPH_SEND_READ_REG_FLAG = 0xE2E2E2E2;
constexpr uint32_t DLPH_SEND_READ_REG_END_FLAG = 0xA2A3A8A9;

constexpr uint32_t DLPH_RECV_READ_REG_FLAG = 0xE3E3E3E3;
constexpr uint32_t DLPH_RECV_READ_REG_END_FLAG = 0xA2A3A8A9;

// package
constexpr uint32_t DLPH_PKG_HEADER_1 = 0xB2B2A4A4;
constexpr uint32_t DLPH_PKG_HEADER_2 = 0xCCCCCCCC;
constexpr uint32_t DLPH_PKG_SIZE = 0x5C0;  // 1472
// raw data with fpga type
constexpr uint32_t DLPH_FPGA_RAW_DATA_HEADER = 0xE7E7E7E7;
constexpr uint32_t DLPH_FPGA_RAW_DATA_TAIL = 0x55555555;
constexpr uint32_t DLPH_FPGA_RAW_DATA_SIZE = 0x5BC;       // 1468
constexpr uint32_t POINTS_NUMBER_PER_PFGA_PACKET = 0x8F;  // 143
// raw data with dsp type
constexpr uint32_t DLPH_DSP_RAW_DATA_HEADER = 0xBEBEBEBE;
constexpr uint32_t DLPH_DSP_RAW_DATA_TAIL = 0xEDEDEDED;
constexpr uint32_t DLPH_DSP_RAW_DATA_SIZE = 0x40E;       // 1038
constexpr uint32_t POINTS_NUMBER_PER_DSP_PACKET = 0x7D;  // 125

// limit
constexpr int32_t LASER_POWER_MIN = 0x32;
constexpr int32_t LASER_POWER_MAX = 0x226;
constexpr int32_t LASER_FACTOR_MIN = 0x01;
constexpr int32_t LASER_FACTOR_MAX = 0x0A;
constexpr int32_t LASER_PULSE_WIDTH_MIN = 0x01;
constexpr int32_t LASER_PULSE_WIDTH_MAX = 0x14;

// version
constexpr int32_t DLPH_LOGIC_VERSION = 0x00;

// files
constexpr char LIDAR_CHECK_FILE[]{"LidarCheckParameter.xml"};
constexpr char LIDAR_LIMIT_FILE[]{"LimitParameter.xml"};
constexpr char LIDAR_PARAMETER_FILE[]{"LidarParameter.xml"};

enum DlphRegisterAddress : uint16_t
{
    LOGIC_VERSION_NUM = 0x00,
    TDC_GPX_REG0 = 0x04,
    TDC_GPX_REG1 = 0x08,
    TDC_GPX_REG2 = 0x0C,
    TDC_GPX_REG3 = 0x10,
    TDC_GPX_REG4 = 0x14,
    TDC_GPX_REG5 = 0x18,
    TDC_GPX_REG6 = 0x1C,
    TDC_GPX_REG7 = 0x20,
    TDC_GPX_REG11 = 0x24,
    TDC_GPX_REG12 = 0x28,
    ROTARY_MOTOR_CTL = 0x2C,
    LASER_TRIGGER_FREQ = 0x30,
    LASER_CTL = 0x34,
    GALVANO1_CTL = 0x38,
    GALVANO2_CTL = 0x3C,
    GALVANO_DAC_CTL1 = 0x40,
    GALVANO_DAC_CTL2 = 0x44,
    GALVANO_DAC_CTL3 = 0x48,
    GALVANO_DAC_SET0 = 0x4C,
    GALVANO_DAC_SET1 = 0x50,
    ETHERNET_CONFIG_REG_0 = 0x54,
    GALVANO2_DAC_INTVL = 0x58,
    GALVANO3_CTL = 0x5C,
    TDC_TIME_RANGE = 0x60,
    STATUS_REG = 0x64,
    TDC_GPX_TIME_RANGE = 0x68,
    GALVANO1_ANGLE_INTVL_1 = 0x6C,
    GALVANO1_ANGLE_INTVL_2 = 0x70,
    GALVANO1_ANGLE_INTVL_3 = 0x74,
    GALVANO1_ANGLE_INTVL_4 = 0x78,
    GALVANO2_ANGLE_INTVL_1 = 0x7C,
    GALVANO2_ANGLE_INTVL_2 = 0x80,
    GALVANO2_ANGLE_INTVL_3 = 0x84,
    GALVANO2_ANGLE_INTVL_4 = 0x88,
    GALVANO_ANGLE_SELECT = 0x8C,
    REG_RW_24_090 = 0x90,
    REG_RW_25_094 = 0x94,
    REG_RW_26_098 = 0x98,
    REG_RW_27_09C = 0x9C,
    REG_RW_28_0A0 = 0xA0,
    REG_RW_29_0A4 = 0xA4,
    REG_RW_2A_0A8 = 0xA8,
    REG_RW_2B_0AC = 0xAC,
    REG_RW_2C_0B0 = 0xB0,
    REG_RW_2D_0B4 = 0xB4,
    REG_RW_2E_0B8 = 0xB8,
    REG_RW_2F_0BC = 0xBC
};

struct DlphRegisterCommand
{
    DlphRegisterCommand() = default;
    DlphRegisterCommand(DlphRegisterAddress addr, uint32_t data) : reg_addr(addr), reg_data(data) {}

    DlphRegisterAddress reg_addr;
    uint32_t reg_data;
};

struct DlphRegisterReadCommand
{
    DlphRegisterReadCommand() = default;
    DlphRegisterReadCommand(DlphRegisterAddress addr) : reg_addr(addr) {}

    DlphRegisterAddress reg_addr;
};

struct RegisterData
{
    int32_t parameters[5] = {0};
};

struct IntervalSetParameter
{
    bool IsValid(int32_t frame, int32_t max_step, int32_t max_speed, int32_t min_single_angle)
    {
        if (frame <= 0)
            return false;

        if (parameters[0] <= 0 || parameters[4] >= 4095)
            return false;

        for (int i = 0; i < 4; i++)
            if (parameters[i] >= parameters[i + 1] ||
                (parameters[i + 1] - parameters[i]) / steps[i] < min_single_angle)
                return false;

        for (int i = 0; i < 4; i++)
            if (steps[i] <= 0)
                return false;

        auto step = steps[0] + steps[1] + steps[2] + steps[3];
        if (step > max_step)
            return false;

        if (speed = step * 12 * frame; speed > max_speed)
            return false;

        if (parameters[0] >= 0 || parameters[4] <= 0)
        {
            zero_position = (parameters[0] + parameters[4]) / 2;
            for (int i = 0; i < 5; i++)
                parameters[i] -= zero_position;
        }

        return true;
    }

    int32_t speed{0};
    int32_t steps[4] = {0};
    int32_t parameters[5] = {0};
    int32_t zero_position{0};
};

typedef std::vector<std::vector<uint8_t>> DataPackets;

DataPackets GetViewFieldPackets(const IntervalSetParameter &param);
DataPackets GetLaserPackets(const LaserParameter &param);
DataPackets GetScanModePackets(ScanMode mode);
DataPackets GetRawDataTypePackets(RawDataType type);
DataPackets GetEchoNumberPackets(int32_t distance, int32_t echo_number);
DataPackets GetVersionPackets(uint32_t version);
DataPackets GetStopDevicePackets(const LidarParameter &param);
DataPackets GetRegisterPackets(DlphRegisterAddress addr, const RegisterData &data);
DataPackets GetReadRegisterPackets(DlphRegisterAddress addr);
DataPackets GetTempraturePackets(uint32_t temprature);
DataPackets GetDACPackets(uint32_t dac);
DataPackets GetDcAndThresholdPackets(uint32_t dc_q, uint32_t dc_i, uint32_t threshold);
DataPackets GetTimeWinPackets(uint32_t min, uint32_t max);
DataPackets GetGatherSizePackets(uint32_t gather_point_size);
DataPackets GetAmplitudeExecludePackets(uint32_t time_stamp, uint32_t amplitude_exclude);
DataPackets GetGhostExecludePackets(uint32_t high_plusewidth, uint32_t time_difference);
DataPackets GetPulsewidthPackets(uint32_t plusewidth_diff, uint32_t time_fly);

DlphRegisterCommand GenerateRegisterCommand(DlphRegisterAddress reg, const RegisterData &data);
DataPackets GetGalvanometerPackets(const std::vector<uint16_t> &in_data, const uint32_t &frame);
// check frame according to the direction of left galvanometer
template <typename DATA_TYPE,
          typename std::enable_if<std::is_base_of<RawDataBase, DATA_TYPE>::value, int>::type = 0>
bool CheckFrame(const DATA_TYPE &data, int32_t &latest_direction, int32_t &current_channel_id)
{
    auto direction_changed = [&latest_direction](int32_t direction) -> bool {
        if (latest_direction == -1)  // we didn't konw the direction at first
            latest_direction = direction;
        if (latest_direction != direction)  // direction changed
        {
            latest_direction = direction;
            return true;
        }
        return false;
    };

    uint16_t operand = 0x8000;
    //主要在支持只有其中一个通道有数据时可以结算数据
    if (current_channel_id == -1 || data.packet_info[0] == current_channel_id)  // left galvanometer
    {
        current_channel_id = data.packet_info[0];
        if constexpr (std::is_same<DATA_TYPE, DlphFPGAData>::value)
        {
            // Check the last data of the packet is enough to find the direction change
            auto direction = data.angle_data[(POINTS_NUMBER_PER_PFGA_PACKET - 1) * 5 + 1] & operand;
            if (direction_changed(direction))
                return true;
        }
    }
    return false;
}

template <typename DATA_TYPE,
          typename std::enable_if<std::is_base_of<RawDataBase, DATA_TYPE>::value, int>::type = 0>
bool CheckFrame(const DATA_TYPE &data, int32_t &latest_direction)
{
    auto direction_changed = [&latest_direction](int32_t direction) -> bool {
        if (latest_direction == -1)  // we didn't konw the direction at first
            latest_direction = direction;
        if (latest_direction != direction)  // direction changed
        {
            latest_direction = direction;
            return true;
        }
        return false;
    };

    uint16_t operand = 0x8000;
    if constexpr (std::is_same<DATA_TYPE, DlphFPGAData>::value)
    {
        // Check the last data of the packet is enough to find the direction change
        auto direction = data.angle_data[(POINTS_NUMBER_PER_PFGA_PACKET - 1) * 5 + 1] & operand;
        if (direction_changed(direction))
            return true;
    }
    return false;
}

}}  // namespace onet::lidar
