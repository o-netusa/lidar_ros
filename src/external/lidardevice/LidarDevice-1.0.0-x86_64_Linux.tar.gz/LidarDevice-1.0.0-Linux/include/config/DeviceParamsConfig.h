/**************************************************************************
 * @file:  DeviceParamsConfig.h
 * @brief: Save and load device parameters
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <common/Global.h>

#include <memory>
#include <string>

#include "DeviceParams.h"

namespace onet { namespace lidar { namespace config {

enum class Serializer
{
    XML,
    JSON
};
template <typename OBJ, Serializer ser = Serializer::XML>
bool DLLEXPORT Deserialize(std::shared_ptr<OBJ>& obj, const std::string& file);

template <typename OBJ, Serializer ser = Serializer::XML>
bool DLLEXPORT Serialize(std::shared_ptr<OBJ> obj, const std::string& file);

template <typename OBJ>
bool DLLEXPORT DeserializeTXT(std::shared_ptr<OBJ>& obj, const std::string& file);

bool DLLEXPORT DeserializeIpPort(std::pair<std::string, int>& obj, const std::string& file);
bool DLLEXPORT SerializeIpPort(std::pair<std::string, int>& obj, const std::string& file);

}}}  // namespace onet::lidar::config
