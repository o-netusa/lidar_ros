/**************************************************************************
 * @file:  Device.h
 * @brief:
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <common/Global.h>
#include <common/Semaphore.h>
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4244)  // stduuid
#endif // _MSC_VER

#if defined(linux) || defined(__linux) || defined(__linux__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wold-style-cast" // uuid
#pragma GCC diagnostic ignored "-Wconversion" // uuid
#pragma GCC diagnostic ignored "-Wsign-conversion" // uuid
#pragma GCC diagnostic ignored "-Wshadow" // uuid
#pragma GCC diagnostic ignored "-Wuseless-cast" // uuid
#endif // linux
#include <uuid.h>
#if defined(linux) || defined(__linux) || defined(__linux__)
#pragma GCC diagnostic pop
#endif // linux
#ifdef _MSC_VER
#pragma warning(pop)
#endif  // _MSC_VER

#include <atomic>

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4244)  // stduuid
#endif // _MSC_VER


#include "DeviceParams.h"
#include "PointCloud.h"

#ifdef _MSC_VER
#pragma warning(pop)
#endif  // _MSC_VER
namespace onet { namespace lidar {

constexpr char DEFAULT_DATA_FOLDER[]{"raw_data"};

/**
 * @brief Specify raw data saving configurations
 * @note Raw data means LiDAR raw data, which can be converted into the stardand point cloud data.
 */
struct RawDataSavingConfig
{
    /**
     * @brief The FolderRule enum
     *   DEFAULT : Generating the folder by date in format 'yyyymmdd'.
     *   SPECIFIED : Generating the folder defined by user. The path must be legal.
     *   EVERY_START: Generating the folder by time in format 'yyyymmddhhmmss' each time Start is
     * called.
     */
    enum class FolderRule
    {
        DEFAULT = 0,
        SPECIFIED = 1,
        EVERY_START = 2
    };
    RawDataSavingConfig(bool is_saving_enabled = false,
                        FolderRule folder_rule = FolderRule::DEFAULT,
                        const std::string &save_path = "")
        : saving_enabled(is_saving_enabled), rule(folder_rule), path(save_path)
    {}

    bool saving_enabled{false};            ///< whether to save raw data
    FolderRule rule{FolderRule::DEFAULT};  ///< the rule of folder generation
    std::string path;                      ///< the folder defined by user
};

/**
 * Base class for LiDAR device and playback device
 */
class DLLEXPORT Device
{
public:
    Device() = default;
    virtual ~Device() = default; // 有子类，析构需定义为虚函数

    /**
     * @brief Get the uuid of device
     */
    virtual const uuids::uuid &GetDeviceId() const { return m_device_id; }

    /**
     * @brief Check if the device is started
     */
    virtual bool IsStarted() const { return m_started; }

    /**
     * @brief Initialize the device
     * @return true on success, false otherwise
     */
    virtual bool Init() = 0;

    /**
     * @brief Start the device
     */
    virtual bool Start() = 0;

    /**
     * @brief Stop the device
     */
    virtual bool Stop() = 0;
#ifdef ENABLE_INTERNAL_CALIB
    /**
     * @brief Enable the process of calculating the points in the specified bounding box
     * @note  If passing in a callback, the callback will be called per point cloud frame.
     */
    virtual void EnableBoxedPointsDetection(
        const BoundingBox &box,
        std::function<void(uint32_t, const DetectedPointsBox &)> callback) = 0;

    /**
     * @brief Disable the process of calculating the points in the specified bounding box
     */
    virtual void DisableBoxedPointsDetection() = 0;
#endif
protected:
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4251)
#endif // _MSC_VER
    uuids::uuid m_device_id{uuids::uuid_random_generator{}()};
    std::atomic_bool m_started{false};
#ifdef _MSC_VER
#pragma warning(pop)
#endif // _MSC_VER
};

}}  // namespace onet::lidar
