/**************************************************************************
 * @file:  ErrorCode.h
 * @brief:
 *
 * Copyright (c) 2021 O-Net Technologies (Group) Limited.
 *************************************************************************/

#pragma once


namespace cppbase {

enum{
	ONET_SUCCESS                           = 0,
	
	ONET_ERR_NETWORK                       = 0x500,   // 网络配置错误
	ONET_ERR_NETWORK_PORT_OCCUPIED,                   // 端口被占用
	
	ONET_ERR_CONFIG_FILE                   = 0x600,   // 配置文件参数错误
	ONET_ERR_CONFIG_LIDAR_PARAMETER,				  // 加载lidar_parameter雷达配置文件错误
	ONET_ERR_CONFIG_CHECK_PARAMETER,				  // 加载check_parameter校准配置文件错误
	ONET_ERR_CONFIG_UDP_PARAMETER,					  // 加载udp_parameter配置文件错误
	ONET_ERR_CONFIG_LIMIT_PARAMETER,				  // 加载limit_parameter参数上限下限配置文件错误
    ONET_ERR_CONFIG_GALVANOMETER_PARAMETER,			  // 加载振镜配置文件错误
    ONET_ERR_CONFIG_VIEW_PARAMETER,					  // lidar_parameter配置文件中的视场角参数错误
													  // 
	ONET_ERR_LIDAR_DEVICE_INITIALIZED       = 0x700,  // lidar_device已初始化
    ONET_ERR_UPPER_LOWER_VERSION_DISMATCH,            // 上下位机版本不匹配
    ONET_ERR_LIDAR_DISCONNECT,                        // 未连接雷达
};

}  // namespace cppbase
