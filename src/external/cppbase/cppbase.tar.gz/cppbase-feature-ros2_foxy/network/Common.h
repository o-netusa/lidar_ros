/**************************************************************************
 * @file:  Common.h
 * @brief: Network common header
 *
 * Copyright (c) 2021 O-Net Technologies (Group) Limited.
 *************************************************************************/

#pragma once

#include <common/Global.h>
#include <logging/Logging.h>

#if defined(linux) || defined(__linux) || defined(__linux__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wsign-conversion"  // asio socket_types.hpp
#pragma GCC diagnostic ignored "-Wconversion"       // asio eventfd_select_interrupter.ipp
#pragma GCC diagnostic ignored \
    "-Wlogical-op"  // asio eventfd_select_interrupter.ipp EWOULDBLOCK EAGAIN
#pragma GCC diagnostic ignored "-Wuseless-cast"         // asio io_control.hpp
#pragma GCC diagnostic ignored "-Wold-style-cast"       // asio socket_ops.ipp
#pragma GCC diagnostic ignored "-Wduplicated-branches"  // asio serial_port_base.ipp
#pragma GCC diagnostic ignored "-Wnull-dereference"     // asio scheduler.ipp
#endif                                                  // linux

#define ASIO_STANDALONE
#include <asio.hpp>

#if defined(linux) || defined(__linux) || defined(__linux__)
#pragma GCC diagnostic pop
#endif  // linux
#include <future>
#include <thread>

#define DEFAULT_BUFSZ 4096

namespace cppbase {
namespace network {

// 如果logger是变量，会在network udp/tcp中 用到这个变量 network::logger->info("")

static asio::io_context io_context;
// executor_work_guard prevents io_context from returning
static asio::executor_work_guard<asio::io_context::executor_type> work_guard{
    asio::make_work_guard(io_context)};
// io_thread keeps io_context running
static std::thread io_thread;

[[maybe_unused]] static void Init()
{
    io_thread = std::thread([] { io_context.run(); });
}

[[maybe_unused]] static void Terminate()
{
    io_context.stop();
    io_thread.join();
}

}  // namespace network

using tcp = asio::ip::tcp;
using udp = asio::ip::udp;

}  // namespace cppbase
