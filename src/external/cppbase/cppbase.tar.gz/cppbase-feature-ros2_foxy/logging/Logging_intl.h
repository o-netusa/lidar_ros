/**************************************************************************
 * @file:  Logging_intl.h
 * @brief: Logging internal implementations
 *
 * Copyright (c) 2021 O-Net Technologies (Group) Limited.
 **************************************************************************/

#include <spdlog/sinks/stdout_color_sinks.h>

#if defined(linux) || defined(__linux) || defined(__linux__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wshadow" // spdlog_setup setup_error.h
#endif // linux

#include <common/FileSystem.h>
#include "spdlog_setup/conf.h"

#if defined(linux) || defined(__linux) || defined(__linux__)
#pragma GCC diagnostic pop
#endif // linux

#ifndef NDEBUG
// 默认 SPDLOG_LEVEL_INFO
#if defined(SPDLOG_ACTIVE_LEVEL)
#undef SPDLOG_ACTIVE_LEVEL
#define SPDLOG_ACTIVE_LEVEL SPDLOG_LEVEL_TRACE //必须定义这个宏,才能输出文件名和行号
#endif // SPDLOG_ACTIVE_LEVEL
#endif // NDEBUG

#ifndef logger
#define logger  (cppbase::logging::GetLoggerForCurrentModule())
#endif // logger

// macro for filename:function:line
#define LOGI(logger_p, ...) SPDLOG_LOGGER_CALL(logger_p, spdlog::level::info, __VA_ARGS__)
#define LOGD(logger_p, ...) SPDLOG_LOGGER_CALL(logger_p, spdlog::level::debug, __VA_ARGS__)
#define LOGW(logger_p, ...) SPDLOG_LOGGER_CALL(logger_p, spdlog::level::warn, __VA_ARGS__)
#define LOGE(logger_p, ...) SPDLOG_LOGGER_CALL(logger_p, spdlog::level::err, __VA_ARGS__)

namespace cppbase { namespace logging {

class Instance
{
public:
    static Instance& GetInstance()
    {
        static Instance instance;
        return instance;
    }

    LoggerPtr GetLoggerByName(const std::string& logger_name) {
        LoggerPtr logger_ret = nullptr;
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) \
    || defined(__linux__) || defined(linux__) || defined(linux)
        logger_ret = spdlog::get(logger_name);
#endif // WIN32 or linux
        return logger_ret;
    }

private:

    Instance()
    {
        // FOR windows and linux： first time to GetLogger, need to set up from file (if possible)
        LogInitSingleInstance();
    }
};

[[maybe_unused]] void SetSpdLogLevel(spdlog::level::level_enum log_level) noexcept
{
    spdlog::set_level(log_level);
    spdlog::flush_on(log_level);
}

void LogInitSingleInstance() noexcept
{
    fs::path log_conf = fs::path(filesystem::GetConfigDir()) / filesystem::LogConfigFilename;
    static bool inited_from_file = false;
    if (fs::exists(log_conf) && !inited_from_file)
    {
        // maybe throw err
        spdlog_setup::from_file(log_conf.generic_string());
        inited_from_file = true;
    } else
    {
        static constexpr const char log_pattern[] = "[%Y-%m-%dT%T%z] [%L] <%n> [thread %t][%@,%!]: %v";
        spdlog::set_pattern(log_pattern);
    }
}

LoggerPtr GetLogger(const std::string& logger_name) noexcept
{
    if (logger_name.empty())
    {
        return spdlog::default_logger();
    }
    auto logger_ret = spdlog::get(logger_name);
    if (logger_ret)
    {
        return logger_ret;
    }

    // try get logger from setup file
    logger_ret = Instance::GetInstance().GetLoggerByName(logger_name);
    if (logger_ret)
    {
        return logger_ret;
    }

    try
    {
        auto default_logger = spdlog::get("default");
        if (default_logger)
        {
            logger_ret = default_logger->clone(logger_name);
        } else
        {
            // no default, use console
            logger_ret = spdlog::stdout_color_mt(logger_name.c_str());
        }
    } catch (const std::exception &ex)
    {
        logger_ret = spdlog::default_logger();
        logger_ret->error(
                    "Error: unable to create logger with name: {0}, "
                "using default logger, msg:{}",
                    logger_name, ex.what());
    }
    return logger_ret;
}

[[maybe_unused]] LoggerPtr GetLoggerForCurrentModule() noexcept
{
#ifdef MODULE_NAME
    return GetLogger(MODULE_NAME);
#else
#error "Error: MODULE_NAME is not defined. Define it in the module's CMakeLists.txt."
#endif
}

}}  // namespace cppbase::logging
