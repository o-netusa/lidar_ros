/**************************************************************************
 * @file:  UuidTests.cpp
 * @brief:
 *
 * Copyright (c) 2021 O-Net Technologies (Group) Limited.
 **************************************************************************/

#include <gtest/gtest.h>
#include <uuid.h>

using namespace uuids;

TEST(UuidTests, Basic)
{
    uuid empty;
    EXPECT_TRUE(empty.is_nil());
    EXPECT_EQ("00000000-0000-0000-0000-000000000000", to_string(empty));
}

TEST(UuidTests, Parse)
{
    {
        auto guid = uuids::uuid::from_string("47183823-2574-4bfd-b411-99ed177d3e43");
        EXPECT_EQ("47183823-2574-4bfd-b411-99ed177d3e43", uuids::to_string(guid));
    }
    {
        auto str = "";
        EXPECT_THROW(uuids::uuid::from_string(str), uuids::uuid_error);
    }
    {
        auto guid = uuids::uuid::from_string(L"47183823-2574-4bfd-b411-99ed177d3e43");
        EXPECT_EQ("47183823-2574-4bfd-b411-99ed177d3e43", uuids::to_string(guid));
    }
    {
        auto guid = uuids::uuid::from_string("00000000-0000-0000-0000-000000000000");
        EXPECT_EQ("00000000-0000-0000-0000-000000000000", uuids::to_string(guid));
    }
}
